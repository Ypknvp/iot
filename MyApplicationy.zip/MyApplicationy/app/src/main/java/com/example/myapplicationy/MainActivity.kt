package com.example.myapplicationy

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.location.*
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var db: SQLiteDatabase
    private lateinit var sharedPref: SharedPreferences
    private lateinit var locationManager: LocationManager
    private val channelId = "basic_channel"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Request Permissions
        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION
        ), 1)

        sharedPref = getSharedPreferences("mypref", Context.MODE_PRIVATE)
        db = openOrCreateDatabase("MyDB", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS Users(name TEXT, phone TEXT)")

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val name = findViewById<EditText>(R.id.name)
        val phone = findViewById<EditText>(R.id.phone)
        val saveBtn = findViewById<Button>(R.id.saveBtn)
        val locationBtn = findViewById<Button>(R.id.locBtn)

        saveBtn.setOnClickListener {
            val n = name.text.toString()
            val p = phone.text.toString()

            db.execSQL("INSERT INTO Users VALUES('$n', '$p')")
            sharedPref.edit().putString("name", n).apply()

            sendSMS(p, "Hello $n, saved successfully!")
            showNotification("Saved!", "User $n saved.")
            showDialog("Saved", "User $n is stored successfully!")
        }

        locationBtn.setOnClickListener {
            fetchAndShowLocation()
        }

        createNotificationChannel()
    }

    private fun fetchAndShowLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val provider = LocationManager.GPS_PROVIDER
            val location = locationManager.getLastKnownLocation(provider)

            if (location == null) {
                Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()
                return
            }

            val latitude = location.latitude
            val longitude = location.longitude

            Thread {
                try {
                    val geocoder = Geocoder(this, Locale.getDefault())
                    val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                    val addressLine = addresses?.firstOrNull()?.getAddressLine(0) ?: "Address not found"

                    runOnUiThread {
                        Toast.makeText(this, "Lat: $latitude\nLong: $longitude\n$addressLine", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, "Geocoder error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Security exception: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSMS(phone: String, msg: String) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null)
            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showNotification(title: String, msg: String) {
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        with(NotificationManagerCompat.from(this)) {
            notify(1, builder.build())
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel() {
        val channel = NotificationChannel(channelId, "Basic Channel", NotificationManager.IMPORTANCE_HIGH)
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun showDialog(title: String, msg: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            Toast.makeText(this, "Settings clicked", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
