package com.example.myapplicationy
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.location.*
import android.os.*
import android.telephony.SmsManager
import android.view.*
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.annotation.RequiresPermission
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var db: SQLiteDatabase
    lateinit var sharedPref: SharedPreferences
    lateinit var locationManager: LocationManager
    val channelId = "basic_channel"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS
        ), 1)

        sharedPref = getSharedPreferences("mypref", Context.MODE_PRIVATE)
        db = openOrCreateDatabase("MyDB", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS Users(name TEXT, phone TEXT)")

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        createNotificationChannel()

        val name = findViewById<EditText>(R.id.name)
        val phone = findViewById<EditText>(R.id.phone)
        val saveBtn = findViewById<Button>(R.id.saveBtn)
        val locBtn = findViewById<Button>(R.id.locBtn)
        val nextPageBtn = findViewById<Button>(R.id.nextPageBtn)

        saveBtn.setOnClickListener {
            val n = name.text.toString()
            val p = phone.text.toString()
            db.execSQL("INSERT INTO Users VALUES('$n', '$p')")
            sharedPref.edit().putString("name", n).apply()
            sendSMS(p, "Hi $n, saved!")
            showNotification("Saved", "User $n saved!")
            showDialog("User saved", "Name: $n\nPhone: $p")
        }

        locBtn.setOnClickListener {
            val location = getLocation()
            Toast.makeText(this, location, Toast.LENGTH_LONG).show()
        }

        nextPageBtn.setOnClickListener {
            startActivity(Intent(this, SecondActivity::class.java))
        }
    }

    private fun getLocation(): String {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return "Permission not granted"
        }
        val location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: return "No location found"
        val geo = Geocoder(this, Locale.getDefault())
        val address = geo.getFromLocation(location.latitude, location.longitude, 1)
        return address?.firstOrNull()?.getAddressLine(0) ?: "Address not found"
    }

    private fun sendSMS(phone: String, msg: String) {
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null)
        } catch (e: Exception) {
            Toast.makeText(this, "SMS Failed", Toast.LENGTH_SHORT).show()
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    private fun showNotification(title: String, message: String) {
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        NotificationManagerCompat.from(this).notify(1, builder.build())
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel() {
        val channel = NotificationChannel(channelId, "Basic Channel", NotificationManager.IMPORTANCE_HIGH)
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun showDialog(title: String, msg: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            Toast.makeText(this, "Settings Clicked", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
